# Advanced - Rock, Paper, Scissors, Lizard & Spock ?!!


## Welcome! 👋


## The challenge

My challenge was to build out this Rock, Paper, Scissors game and get it looking as close to the design as possible.

Unfortunately, I was unable to compete the CSS portion of this project before my release date... so dissapointing, I know.
I got the logic of the game working with my JavaScript and jQuery skills, used Bootstrap 5 to handle the majority of my layout design and the style guide to match the colors and backgrounds, etc.
I loved this assignment, it was so much better than the original project we did for week 13. With that in mind, I will add this to my portfolio page so that I can complete it on the other side of the fence next week.
Time, we either have too much, or not enough it seems...


Eric H. Petross
RI-JJM-6
Web Development Fundamentals

Your users ARE be able to:

- Maintain the state of the score after refreshing the browser _(optional)_
- **Bonus**: Play Rock, Paper, Scissors, Lizard, Spock against the computer _(optional)_

### Rules

If the player wins, they gain 1 point. If the computer wins, the player loses one point.

#### Bonus

- Scissors beats Paper
- Paper beats Rock
- Rock beats Lizard
- Lizard beats Spock
- Spock beats Scissors
- Scissors beats Lizard
- Paper beats Spock
- Rock beats Scissors
- Lizard beats Paper
- Spock beats Rock

**Have fun building!** 🚀

##### Technologies Used

- Bootstrap 5
- jQuery
- vanilla JavaScript